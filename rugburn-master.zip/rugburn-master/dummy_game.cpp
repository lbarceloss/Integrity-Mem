#include <windows.h>
#include <iostream>

int main() {
    std::cout << "[Dummy Game] Iniciando..." << std::endl;

    HMODULE hLib = LoadLibraryA("ijl15.dll");
    if (!hLib) {
        std::cerr << "[Dummy Game] Falha ao carregar ijl15.dll. Verifique se o build ocorreu corretamente." << std::endl;
        system("pause");
        return 1;
    }
    std::cout << "[Dummy Game] ijl15.dll carregada (AntiCheat Injetado via DllMain)!" << std::endl;
    std::cout << "[Dummy Game] O Dummy game esta rodando como um processo fantasma, segurando a DLL viva." << std::endl;
    std::cout << "[Dummy Game] Pressione CTRL+C na janela para encerra-lo!" << std::endl;
    
    Sleep(INFINITE);
    
    return 0;
}
