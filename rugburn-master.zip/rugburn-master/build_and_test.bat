@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat"
echo Compilando Projeto ijl15.dll (rugburn)...
msbuild rugburn.sln /p:Configuration=Release /p:Platform=x86 /p:PlatformToolset=v143 /v:m

echo Compilando AntiCheatServer...
cl /EHsc /MD Server_AntiCheat\AntiCheatServer.cpp /link ws2_32.lib advapi32.lib /OUT:AntiCheatServer.exe

echo Compilando Dummy Game...
cl /EHsc /MD dummy_game.cpp /link user32.lib /OUT:dummy_game.exe

echo Copiando ijl15.dll para a pasta atual...
copy /Y "out\Win32\Release\ijl15.dll" "ijl15.dll"

echo Build concluido.
