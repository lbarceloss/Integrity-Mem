
CREATE TABLE Logs_AntiCheat (
    ID INT IDENTITY(1,1) PRIMARY KEY,        
    Endereco_IP VARCHAR(50) NOT NULL,        
    ID_Jogador INT NULL,                    
    Status_Retornado VARCHAR(50) NOT NULL,  
    Data_Registro DATETIME DEFAULT GETDATE()
);


CREATE INDEX IX_Endereco_IP ON Logs_AntiCheat(Endereco_IP);
CREATE INDEX IX_Status ON Logs_AntiCheat(Status_Retornado);