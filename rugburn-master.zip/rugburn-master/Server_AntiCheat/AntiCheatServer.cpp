#include <iostream>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <thread>
#include <chrono>
#include <mutex>
#include <vector>

#pragma comment(lib, "Ws2_32.lib")

#define DEFAULT_PORT "8080"
#define DEFAULT_IP "127.0.0.1"
#define HEARTBEAT_INTERVAL_MS 15000 // 15 sec


#include <wincrypt.h>
#pragma comment(lib, "advapi32.lib")

const std::string SECRET_KEY = "MeuAntiCheatPangya_SuperSecreto2026";

std::string DecryptData(const std::string& input) {
    HCRYPTPROV hProv;
    HCRYPTKEY hKey;
    HCRYPTHASH hHash;
    
    if (!CryptAcquireContext(&hProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        return input; 
    }
    
    CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash);
    CryptHashData(hHash, (BYTE*)SECRET_KEY.c_str(), (DWORD)SECRET_KEY.length(), 0);
    CryptDeriveKey(hProv, CALG_AES_256, hHash, 0, &hKey);
    
    DWORD dwDataLen = (DWORD)input.length();
    if (dwDataLen == 0) return "";
    
    BYTE* pbData = new BYTE[dwDataLen];
    memcpy(pbData, input.c_str(), dwDataLen);
    
    if (CryptDecrypt(hKey, 0, TRUE, 0, pbData, &dwDataLen)) {
        std::string result((char*)pbData, dwDataLen);
        delete[] pbData;
        CryptDestroyKey(hKey);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return result;
    }
    
    delete[] pbData;
    CryptDestroyKey(hKey);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);
    return "DECRYPT_ERROR"; 
}


std::mutex g_LogMutex;

void LogMessage(const std::string& msg) {
    std::lock_guard<std::mutex> lock(g_LogMutex);
    std::cout << msg << std::endl;
}


void ClientSessionThread(SOCKET ClientSocket, struct sockaddr_in ClientAddr) {
    char ipBuf[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(ClientAddr.sin_addr), ipBuf, INET_ADDRSTRLEN);
    
    LogMessage(std::string("[+] Cliente conectado: ") + ipBuf);

    DWORD recvTimeout = 15000; 
    setsockopt(ClientSocket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&recvTimeout, sizeof(recvTimeout));

    bool isRunning = true;

    while (isRunning) {
        unsigned int challengeNum = GetTickCount();
        std::string challengeStr = std::to_string(challengeNum);
        
        int sendResult = send(ClientSocket, challengeStr.c_str(), (int)challengeStr.length(), 0);
        if (sendResult == SOCKET_ERROR) {
            LogMessage(std::string("[-] Erro ao enviar challenge para ") + ipBuf + " -> " + std::to_string(WSAGetLastError()));
            break;
        }

        char recvbuf[512];
        int iResult = recv(ClientSocket, recvbuf, sizeof(recvbuf) - 1, 0);
        
        if (iResult > 0) {
            recvbuf[iResult] = '\0'; 

            std::string decrypted_str = DecryptData(std::string(recvbuf, iResult));
            
            if (decrypted_str.find(challengeStr) == std::string::npos) {
                LogMessage(std::string("\n[!] ALERTA: Resposta ao desafio falhou para ") + ipBuf + ". Possivel emula\xc3\xa7\xc3\xa3o!");
                break; 
            }

            if (decrypted_str.find("HACK_DETECTED") != std::string::npos) {
                LogMessage(std::string("\n[!] ALERTA CRITICO: HACK FOI DETECTADO NO CLIENTE ") + ipBuf + "!");

            }
            else if (decrypted_str.find("OK") != std::string::npos) {
                LogMessage(std::string("[INFO] ") + ipBuf + " relatou o status: Limpo. (Packet: " + decrypted_str + ")");
            }
            else {
                LogMessage(std::string("[-] Mensagem desconhecida recebida de ") + ipBuf + ": " + decrypted_str);
            }
        }
        else if (iResult == 0) {
            LogMessage(std::string("[INFO] Conexao encerrada pelo cliente ") + ipBuf);
            break;
        }
        else {
            int err = WSAGetLastError();
            if (err == WSAETIMEDOUT) {
                LogMessage(std::string("\n[!] ALERTA: Cliente ") + ipBuf + " sofreu TIMEOUT. O Anticheat pode ter sido fechado!");
            } else {
                LogMessage(std::string("[-] Erro no recebimento de ") + ipBuf + " -> " + std::to_string(err));
            }
            break;
        }

        int waitMs = HEARTBEAT_INTERVAL_MS;
        while (waitMs > 0 && isRunning) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            waitMs -= 100;
        }
    }

    LogMessage(std::string("[-] Encerrando conexao com ") + ipBuf);
    closesocket(ClientSocket);
}

int main() {
    WSADATA wsaData;
    int iResult;

    SOCKET ListenSocket = INVALID_SOCKET;

    struct addrinfo* result = NULL;
    struct addrinfo hints;

    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        std::cerr << "WSAStartup falhou com o erro: " << iResult << std::endl;
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    iResult = getaddrinfo(DEFAULT_IP, DEFAULT_PORT, &hints, &result);
    if (iResult != 0) {
        std::cerr << "getaddrinfo falhou com o erro: " << iResult << std::endl;
        WSACleanup();
        system("pause");
        return 1;
    }

    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET) {
        std::cerr << "Falha na criacao do socket: " << WSAGetLastError() << std::endl;
        freeaddrinfo(result);
        WSACleanup();
        system("pause");
        return 1;
    }

    iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR) {
        std::cerr << "Falha no Bind (Porta 8080 pode ja estar em uso!): " << WSAGetLastError() << std::endl;
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        system("pause");
        return 1;
    }

    freeaddrinfo(result);

    iResult = listen(ListenSocket, SOMAXCONN);
    if (iResult == SOCKET_ERROR) {
        std::cerr << "Falha no Listen: " << WSAGetLastError() << std::endl;
        closesocket(ListenSocket);
        WSACleanup();
        system("pause");
        return 1;
    }

    std::cout << "[*] Servidor Anti-Cheat Multi-Thread iniciado." << std::endl;
    std::cout << "[*] Aguardando conexoes (Heartbeat a cada " << (HEARTBEAT_INTERVAL_MS / 1000) << " segundos) na porta " << DEFAULT_PORT << "..." << std::endl;

    while (true) {
        struct sockaddr_in ClientAddr;
        int clientAddrSize = sizeof(ClientAddr);

        SOCKET ClientSocket = accept(ListenSocket, (struct sockaddr*)&ClientAddr, &clientAddrSize);
        if (ClientSocket == INVALID_SOCKET) {
            std::cerr << "Falha na aceitacao: " << WSAGetLastError() << std::endl;
            continue;
        }

        std::thread t(ClientSessionThread, ClientSocket, ClientAddr);
        t.detach();
    }

    closesocket(ListenSocket);
    WSACleanup();
    return 0;
}
