@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat"
cl /EHsc /MD test_heartbeat_client.cpp /link ws2_32.lib advapi32.lib /OUT:test_heartbeat_client.exe
