#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <string>

#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "advapi32.lib")

const std::string SECRET_KEY = "MeuAntiCheatPangya_SuperSecreto2026";

std::string EncryptData(const std::string& input) {
    HCRYPTPROV hProv;
    HCRYPTKEY hKey;
    HCRYPTHASH hHash;
    
    if (!CryptAcquireContext(&hProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
        return input; 
    }
    
    CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash);
    CryptHashData(hHash, (BYTE*)SECRET_KEY.c_str(), (DWORD)SECRET_KEY.length(), 0);
    CryptDeriveKey(hProv, CALG_AES_256, hHash, 0, &hKey);
    
    DWORD dwDataLen = (DWORD)input.length();
    DWORD dwBufLen = dwDataLen + 16; 
    BYTE* pbData = new BYTE[dwBufLen];
    memcpy(pbData, input.c_str(), dwDataLen);
    
    if (CryptEncrypt(hKey, 0, TRUE, 0, pbData, &dwDataLen, dwBufLen)) {
        std::string result((char*)pbData, dwDataLen);
        delete[] pbData;
        CryptDestroyKey(hKey);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return result;
    }
    
    delete[] pbData;
    CryptDestroyKey(hKey);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);
    return input; 
}

int main() {
    WSADATA wsaData;
    SOCKET ConnectSocket = INVALID_SOCKET;
    struct sockaddr_in clientService;
    
    std::cout << "[Test Client] Iniciando Winsock..." << std::endl;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != NO_ERROR) {
        system("pause");
        return 1;
    }

    ConnectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (ConnectSocket == INVALID_SOCKET) {
        system("pause");
        return 1;
    }

    clientService.sin_family = AF_INET;
    inet_pton(AF_INET, "127.0.0.1", &clientService.sin_addr); 
    clientService.sin_port = htons(8080);

    std::cout << "[Test Client] Conectando ao AntiCheat Server..." << std::endl;
    iResult = connect(ConnectSocket, (SOCKADDR*)&clientService, sizeof(clientService));
    if (iResult == SOCKET_ERROR) {
        std::cout << "[Test Client] Erro ao conectar. Servidor est\xc3\xa1 ligado?" << std::endl;
        closesocket(ConnectSocket);
        system("pause");
        return 1;
    }
    
    std::cout << "[Test Client] Conectado! Aguardando o Heartbeat Challenge do server..." << std::endl;
    char recvbuf[512];
    
    // Aguarda o challenge
    iResult = recv(ConnectSocket, recvbuf, 511, 0);
    if (iResult > 0) {
        recvbuf[iResult] = '\0';
        std::cout << "[Test Client] Desafio Recebido: " << recvbuf << std::endl;
        
        // Simular a resposta do AntiCheat
        std::string statusMsg = std::string("OK:") + recvbuf;
        
        std::string encryptedMsg = EncryptData(statusMsg);
        
        std::cout << "[Test Client] Respondendo: " << statusMsg << " (Criptografado com tamanho: " << encryptedMsg.length() << ")" << std::endl;
        
        send(ConnectSocket, encryptedMsg.c_str(), (int)encryptedMsg.length(), 0);
        
        std::cout << "[Test Client] Sucesso! Segurando a conexao ativa aguardando o proximo..." << std::endl;
    }
    
    // Fica vivo recebendo heartbeats
    while(1) {
        iResult = recv(ConnectSocket, recvbuf, 511, 0);
        if (iResult > 0) {
            recvbuf[iResult] = '\0';
            std::cout << "[Test Client] Heartbeat Recebido: " << recvbuf << std::endl;
            std::string statusMsg = std::string("OK:") + recvbuf;
            
            // Falso positivo random
            if ((rand() % 100) < 20) {
                statusMsg = std::string("HACK_DETECTED:") + recvbuf;
            }
            
            std::string encryptedMsg = EncryptData(statusMsg);
            std::cout << "[Test Client] Respondendo: " << statusMsg << " (Criptografado com tamanho: " << encryptedMsg.length() << ")" << std::endl;
            send(ConnectSocket, encryptedMsg.c_str(), (int)encryptedMsg.length(), 0);
        } else {
            break; // se der erro, cai fora
        }
    }
    
    closesocket(ConnectSocket);
    WSACleanup();
    system("pause");
    return 0;
}
